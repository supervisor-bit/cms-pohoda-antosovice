<?php
// Zobrazit všechny chyby pro debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Databázová konfigurace
define('DB_HOST', 'localhost:8889'); // MAMP používá port 8889
define('DB_NAME', 'moje_cms');
define('DB_USER', 'root');
define('DB_PASS', 'root'); // Změňte podle vašeho nastavení MAMP

// Základní konfigurace webu
define('SITE_TITLE', 'Pohoda Antošovice');
define('SITE_DESCRIPTION', 'Naturistický kemp - relaxace v harmonii s přírodou');
define('SITE_URL', 'http://localhost:8888/moje_cms');

// Cesty
define('BASE_PATH', __DIR__);
define('UPLOADS_PATH', BASE_PATH . '/uploads/');
define('UPLOADS_URL', SITE_URL . '/uploads/');

// Nastavení session
session_start();

// Připojení k databázi
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Chyba připojení k databázi: " . $e->getMessage());
}

// Funkce pro bezpečnost
function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function isLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function requireLogin() {
    if (!isLoggedIn()) {
        // Zjistíme, jestli jsme už v admin složce nebo ne
        $current_dir = basename(dirname($_SERVER['PHP_SELF']));
        if ($current_dir === 'admin') {
            header('Location: login.php');
        } else {
            header('Location: admin/login.php');
        }
        exit;
    }
}
?>
