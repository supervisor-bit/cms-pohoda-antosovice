-- Databáze pro Naturistický kemp Pohoda Antošovice
-- Vygenerováno: 2025-08-19 20:44:02

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin` VALUES
('2', 'admin', '$2y$10$haIOZkw1f1YW3jA7hHJq/eBz4sxHF8nbIrkXU79K6kCjYdQMZl9Qi', '2025-08-17 22:45:36');

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admins` VALUES
('1', 'admin', '$2y$10$v0vNj8tRO0E9DiEkowMXfu75nxW3CIi/CD4ROvIeN6L2FnvsId0oG', 'admin@test.cz', NULL, NULL, '2025-08-17 22:51:04');

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `meta_description` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('published','draft') COLLATE utf8mb4_unicode_ci DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_published` tinyint(1) DEFAULT '1',
  `menu_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pages` VALUES
('1', 'O kempu', 'o-kempu', '<h2>Vítejte v kempu Pohoda Antošovice</h2><p>Náš naturistický kemp se nachází v malebném prostředí moravských kopců, kde si můžete odpočinout v harmonii s přírodou. Kemp nabízí klidné a bezpečné prostředí pro všechny věkové kategorie.</p><h3>Co nabízíme:</h3><ul><li>Prostorné parcely pro stany a karavany</li><li>Moderní sanitární zařízení</li><li>Společenskou místnost</li><li>Dětské hřiště</li><li>Sportovní vyžití</li></ul>', 'Informace o našem naturistickém kempu Pohoda Antošovice', NULL, 'fas fa-info-circle', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('2', 'Ubytování', 'ubytovani', '<h2>Možnosti ubytování</h2><p>V kempu Pohoda Antošovice nabízíme různé typy ubytování podle vašich potřeb.</p><h3>Místa pro stany</h3><p>Prostorné travnaté parcely s přípojkou elektřiny. Ideální pro milovníky kempování pod širým nebem.</p><h3>Místa pro karavany</h3><p>Zpevněná místa s kompletní infrastrukturou - elektřina, voda, kanalizace.</p><h3>Chaty</h3><p>Pohodlné dřevěné chaty pro 2-4 osoby s vlastním sociálním zařízením.</p>', 'Možnosti ubytování v naturistickém kempu', NULL, 'fas fa-bed', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('3', 'Ceník', 'cenik', '<h2>Ceník služeb - sezóna 2025</h2><h3>Základní poplatky (na osobu/den)</h3><ul><li><strong>Dospělí:</strong> 150 Kč/den</li><li><strong>Děti 6-15 let:</strong> 100 Kč/den</li><li><strong>Děti do 6 let:</strong> zdarma</li></ul><h3>Ubytování</h3><ul><li><strong>Stan (parcela):</strong> 80 Kč/den</li><li><strong>Karavan (parcela):</strong> 120 Kč/den</li><li><strong>Chata 2 lůžka:</strong> 800 Kč/den</li><li><strong>Chata 4 lůžka:</strong> 1200 Kč/den</li></ul><h3>Dodatečné služby</h3><ul><li><strong>Elektřina:</strong> 50 Kč/den</li><li><strong>Wifi:</strong> zdarma</li><li><strong>Parkování:</strong> zdarma</li></ul><p><img src=\"https://www.snoantosovice.cz/images/mapy.png\" alt=\"Obrázek\"></p>', 'Aktuální ceník služeb kempu na rok 2025', NULL, 'fas fa-euro-sign', NULL, 'published', '2025-08-17 19:51:13', '2025-08-19 21:46:47', '1', '0'),
('4', 'Kontakt', 'kontakt', '<h2>Kontaktní informace</h2><h3>Adresa</h3><p>Kemp Pohoda Antošovice<br>Antošovice 123<br>739 53 Antošovice</p><h3>Kontakt</h3><p><strong>Telefon:</strong> +420 123 456 789<br><strong>Email:</strong> info@pohoda-antosovice.cz</p><h3>Otevírací doba</h3><p><strong>Hlavní sezóna (květen-září):</strong><br>Po-Ne: 8:00 - 22:00</p><p><strong>Mimosezóna:</strong><br>Po domluvě</p>', 'Kontaktní informace a lokace kempu Pohoda Antošovice', NULL, 'fas fa-phone', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 20:04:24', '1', '0'),
('5', 'GDPR', 'gdpr', '<h2>Ochrana osobních údajů</h2><p>Kemp Pohoda Antošovice respektuje vaše právo na ochranu osobních údajů a postupuje v souladu s nařízením GDPR.</p><h3>Jaké údaje zpracováváme</h3><ul><li>Jméno a příjmení</li><li>Kontaktní údaje (telefon, email)</li><li>Údaje o pobytu (datum, typ ubytování)</li></ul><h3>Účel zpracování</h3><p>Vaše osobní údaje zpracováváme pouze pro účely:</p><ul><li>Poskytování ubytovacích služeb</li><li>Komunikace ohledně rezervace</li><li>Plnění zákonných povinností</li></ul>', 'Informace o zpracování osobních údajů podle GDPR', NULL, 'fas fa-shield-alt', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('6', 'Členství', 'clenstvi', '<h2>Členství v kempu</h2><p>Staňte se členy našeho kempu a užívejte si výhody celoročního přístupu.</p><h3>Výhody členství</h3><ul><li>Sleva 20% na ubytování</li><li>Priorita při rezervacích</li><li>Přístup do členských prostor</li><li>Účast na členských akcích</li></ul><h3>Jak se stát členem</h3><p>Vyplňte přihlášku a uhraďte roční poplatek. Více informací získáte na recepci nebo telefonicky.</p>', 'Informace o členství v naturistickém kempu', NULL, 'fas fa-users', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('7', 'Stanovy', 'stanovy', '<h2>Stanovy kempu</h2><p>Oficiální stanovy kempu Pohoda Antošovice upravují pravidla členství a provozu.</p><h3>Základní ustanovení</h3><ul><li>Kemp je určen pro naturistickou rekreaci</li><li>Dodržování vzájemného respektu</li><li>Ochrana soukromí všech hostů</li></ul><h3>Plné znění</h3><p>Kompletní text stanov si můžete vyžádat na recepci kempu nebo stáhnout v sekci dokumentů.</p>', 'Stanovy naturistického kempu Pohoda Antošovice', NULL, 'fas fa-file-alt', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('8', 'Provozní řád', 'provozni-rad', '<h2>Provozní řád kempu</h2><p>Provozní řád upravuje chod kempu a pravidla pro všechny hosty.</p><h3>Obsah řádu</h3><ul><li>Základní pravidla pobytu</li><li>Provoz jednotlivých lokalit</li><li>Bezpečnostní opatření</li><li>Parkování a doprava</li></ul><p>Podrobné informace najdete v jednotlivých sekcích provozního řádu.</p>', 'Provozní řád naturistického kempu', NULL, 'fas fa-clipboard-list', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('9', 'Základní pravidla', 'zakladni-pravidla', '<h2>Základní pravidla kempu</h2><p>Pro příjemný pobyt všech hostů dodržujte prosím tato základní pravidla:</p><h3>Naturismus</h3><ul><li>Respektujte naturistický charakter kempu</li><li>Oblečení pouze v označených zónách</li><li>Úcta k přírodě a čistému prostředí</li></ul><h3>Vzájemný respekt</h3><ul><li>Dodržujte soukromí ostatních</li><li>Žádné fotografování bez souhlasu</li><li>Slušné chování ke všem</li></ul>', 'Základní pravidla naturistického kempu', NULL, 'fas fa-gavel', 'provozni-rad', 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('10', 'Provoz lokality', 'provoz-lokality', '<h2>Provoz kempu</h2><p>Informace o provozu jednotlivých částí kempu.</p><h3>Provozní doba</h3><ul><li>Recepce: 8:00 - 20:00</li><li>Restaurace: 12:00 - 22:00</li><li>Bazén: 9:00 - 21:00</li><li>Sauna: 16:00 - 22:00</li></ul><h3>Noční klid</h3><p>Od 22:00 do 7:00 prosíme o dodržování nočního klidu.</p>', 'Informace o provozu kempu a jeho částí', NULL, 'fas fa-clock', 'provozni-rad', 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('11', 'Bezpečnost', 'bezpecnost', '<h2>Bezpečnost v kempu</h2><p>Bezpečnost našich hostů je prioritou.</p><h3>Bezpečnostní opatření</h3><ul><li>Oplocený a hlídaný areál</li><li>Kamerový systém</li><li>Noční hlídka</li><li>Lékárnička na recepci</li></ul><h3>Nouzové kontakty</h3><ul><li>Recepce: +420 123 456 789</li><li>Lékařská pohotovost: 155</li><li>Policie: 158</li></ul>', 'Bezpečnostní opatření a nouzové kontakty', NULL, 'fas fa-shield-alt', 'provozni-rad', 'published', '2025-08-17 19:51:13', '2025-08-17 20:04:24', '1', '0'),
('12', 'Parkování', 'parkovani', '<h2>Parkování v kempu</h2><p>Informace o parkování vozidel v areálu kempu.</p><h3>Parkovací místa</h3><ul><li>Hlavní parkoviště u vstupu</li><li>Parkoviště u chat</li><li>Místa pro karavany</li></ul><h3>Pravidla</h3><ul><li>Rychlost max. 10 km/h</li><li>Parkování pouze na označených místech</li><li>Zákaz parkování po 22:00</li></ul>', 'Pravidla parkování vozidel v kempu', NULL, 'fas fa-parking', 'provozni-rad', 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('13', 'Ubytování - příloha', 'ubytovani-priloha', '<h2>Detaily ubytování</h2><p>Podrobné informace o jednotlivých typech ubytování.</p><h3>Chaty</h3><p>Chaty jsou vybaveny postelemi, stolem, židlemi a vlastním sociálním zařízením.</p><h3>Karavanové stání</h3><p>Zpevněná stání s přípojkami elektřiny, vody a kanalizace.</p><h3>Stanová místa</h3><p>Travnatá místa s možností připojení elektřiny.</p>', 'Podrobnosti o jednotlivých typech ubytování', NULL, 'fas fa-home', 'provozni-rad', 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('14', 'Odpady', 'odpady', '<h2>Nakládání s odpady</h2><p>Pravidla pro třídění a likvidaci odpadů v kempu.</p><h3>Třídění odpadů</h3><ul><li>Směsný komunální odpad</li><li>Plasty a kovy</li><li>Papír a kartony</li><li>Sklo</li><li>Bioodpad</li></ul><h3>Místa sběru</h3><p>Kontejnery na tříděný odpad najdete u hlavního parkoviště a u sanitárních zařízení.</p>', 'Pravidla třídění a likvidace odpadů', NULL, 'fas fa-recycle', 'provozni-rad', 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('15', 'Ceník - příloha', 'cenik-priloha', '<h2>Podrobný ceník</h2><p>Kompletní přehled všech služeb a jejich cen.</p><h3>Sezónní slevy</h3><ul><li>Květen a září: -15%</li><li>Pobyt nad 7 dní: -10%</li><li>Členové kempu: -20%</li></ul><h3>Platební podmínky</h3><p>Platba v hotovosti nebo kartou. Pro pobyty nad 3 dny možnost zálohy.</p>', 'Detailní ceník a slevové akce', NULL, 'fas fa-money-bill-alt', 'provozni-rad', 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('16', 'Plán činnosti', 'plan-cinnosti', '<h2>Plán činnosti kempu</h2><p>Přehled plánovaných akcí a činností v kempu.</p><h3>Pravidelné akce</h3><ul><li>Pátek: Grilování a hudba</li><li>Sobota: Sportovní turnaje</li><li>Neděle: Rodinné aktivity</li></ul><h3>Speciální události</h3><p>Informace o speciálních akcích najdete na nástěnce a našich webových stránkách.</p>', 'Plán akcí a činností v kempu', NULL, 'fas fa-calendar-alt', 'provozni-rad', 'published', '2025-08-17 19:51:13', '2025-08-17 20:11:36', '1', '0'),
('17', 'Testovací stránka', 'test-stranka', '<h2>Toto je testovací stránka</h2><p>Tato stránka byla vytvořena pro ověření, že menu se generuje dynamicky z databáze.</p><h3>Funkčnost:</h3><ul><li>✅ Automatické přidání do menu</li><li>✅ Správné zobrazení obsahu</li><li>✅ Funkční navigace</li></ul><p>Pokud vidíte tuto stránku v menu, znamená to, že dynamické generování menu funguje perfektně! ?</p>', 'Testovací stránka pro ověření dynamického menu', NULL, 'fas fa-clipboard-list', NULL, 'published', '2025-08-17 19:59:48', '2025-08-17 20:04:24', '1', '0'),
('18', 'Test submenu', 'test-submenu', '<h2>Testovací podstránka</h2><p>Tato stránka je podstránkou \"Provozního řádu\" a testuje funkčnost dynamického submenu.</p><h3>Co testujeme:</h3><ul><li>✅ Automatické zařazení do submenu</li><li>✅ Správná hierarchie</li><li>✅ Funkční breadcrumbs</li></ul><p>Pokud se tato stránka objevila v submenu \"Provozní řád\", dynamické menu funguje perfektně! ?</p>', 'Testovací podstránka pro ověření dynamického submenu', NULL, 'fas fa-cogs', 'provozni-rad', 'published', '2025-08-17 19:59:58', '2025-08-17 20:04:24', '1', '0');

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('published','draft') COLLATE utf8mb4_unicode_ci DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_published` tinyint(1) DEFAULT '1',
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `posts` VALUES
('1', 'Vítejte na našich stránkách', 'vitejte-na-nasich-strankach', '<p>Jsme rádi, že jste navštívili naše stránky. Náš naturistický kemp Pohoda Antošovice nabízí jedinečný zážitek v souladu s přírodou.</p><p>Nachází se v malebném prostředí moravských kopců, kde si můžete užít klid a relaxaci daleko od shonu města. Kemp je určen pro všechny věkové kategorie a nabízí bezpečné prostředí pro naturistickou rekreaci.</p><p><img src=\"uploads/2025-08-19_19-41-03_68a4d34f1993b.jpg\" alt=\"pic01.jpg\"></p>', 'Úvodní článek o kempu Pohoda Antošovice', NULL, 'published', '2025-08-17 19:51:13', '2025-08-19 21:41:09', '1', NULL),
('2', 'Nová sezóna 2025', 'nova-sezona-2025', '<p>Těšíme se na novou sezónu 2025! Připravili jsme pro vás mnoho novinek a vylepšení:</p><ul><li>Nově zrekonstruované chaty s moderním vybavením</li><li>Modernizované sanitární zařízení</li><li>Nové sportoviště pro volejbal a badminton</li><li>Zlepšené WiFi pokrytí v celém areálu</li></ul><p>Rezervace na sezónu 2025 již přijímáme!</p>', 'Novinky a vylepšení pro sezónu 2025', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 19:51:13', '1', NULL),
('3', 'Jarní přípravy kempu', 'jarni-pripravy-kempu', '<p>Březen je měsíc, kdy začínáme s přípravami kempu na novou sezónu. Naši pracovníci se starají o údržbu všech zařízení:</p><ul><li>Kontrola a oprava chat</li><li>Údržba sanitárních zařízení</li><li>Příprava zahradních úprav</li><li>Kontrola bezpečnostních systémů</li></ul><p>Vše bude připraveno k zahájení sezóny v květnu!</p>', 'Přípravy kempu na novou sezónu', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 19:51:13', '1', NULL),
('4', 'Letní aktivity a programy', 'letni-aktivity-programy', '<p>Během letní sezóny pořádáme různé aktivity pro naše hosty:</p><h3>Sportovní aktivity</h3><ul><li>Aqua aerobic v bazénu</li><li>Volejbalové turnaje</li><li>Ranní cvičení</li></ul><h3>Společenské akce</h3><ul><li>Hudební večery</li><li>Tematické party</li><li>Grilování pod hvězdami</li></ul><p>Program aktivit najdete vždy na nástěnce u recepce.</p>', 'Letní aktivity a společenské akce v kempu', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 19:51:13', '1', NULL),
('5', 'Bezpečnost a pravidla', 'bezpecnost-pravidla', '<p>Bezpečnost našich hostů je pro nás priorita. Proto dodržujte prosím základní pravidla:</p><h3>Bezpečnostní opatření</h3><ul><li>Kemp je oplocený a hlídaný</li><li>Vstup pouze pro registrované hosty</li><li>Kamerový systém ve společných prostorách</li></ul><h3>Děti v kempu</h3><p>Děti do 16 let musí být neustále pod dohledem rodičů. V kempu máme dětské hřiště a bezpečné prostory pro hry.</p>', 'Informace o bezpečnosti a pravidlech kempu', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 19:51:13', '1', NULL),
('6', 'Podzimní speciální nabídky', 'podzimni-specialni-nabidky', '<p>I v podzimních měsících nabízíme speciální pobyty:</p><h3>Podzimní víkendy</h3><ul><li>Sleva 30% na ubytování v říjnu</li><li>Speciální wellness programy</li><li>Saunování pod hvězdami</li></ul><p>Podzim v kempu má své kouzlo - barevné listí, teplé dny a chladnější večery ideální pro relaxaci.</p>', 'Podzimní nabídky a slevy na ubytování', NULL, 'published', '2025-08-17 19:51:13', '2025-08-17 19:51:13', '1', NULL);

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE `reservations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL,
  `guests` int DEFAULT '1',
  `accommodation_type` enum('tent','caravan','cabin') COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','confirmed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` VALUES
('1', 'site_title', 'Kemp Pohoda Antošovice', '2025-08-17 19:51:13'),
('2', 'site_description', 'Naturistický kemp - relaxace v harmonii s přírodou', '2025-08-17 19:51:13'),
('3', 'contact_phone', '+420 123 456 789', '2025-08-17 19:51:13'),
('4', 'contact_email', 'info@pohoda-antosovice.cz', '2025-08-17 19:51:13'),
('5', 'contact_address', 'Antošovice 123, 739 53 Antošovice', '2025-08-17 19:51:13'),
('6', 'facebook_url', 'https://www.facebook.com/pohoda.antosovice', '2025-08-17 19:51:13'),
('7', 'instagram_url', '', '2025-08-17 19:51:13'),
('10', 'camp_capacity', '50', '2025-08-17 19:51:13'),
('11', 'price_adult', '150', '2025-08-17 19:51:13'),
('12', 'price_child', '100', '2025-08-17 19:51:13'),
('13', 'price_tent', '80', '2025-08-17 19:51:13'),
('14', 'price_caravan', '120', '2025-08-17 19:51:13'),
('15', 'price_cabin_2', '800', '2025-08-17 19:51:13'),
('16', 'price_cabin_4', '1200', '2025-08-17 19:51:13'),
('17', 'price_electricity', '50', '2025-08-17 19:51:13'),
('18', 'season_start', '2025-05-01', '2025-08-17 19:51:13'),
('19', 'season_end', '2025-09-30', '2025-08-17 19:51:13'),
('20', 'operating_hours_reception', '8:00 - 20:00', '2025-08-17 19:51:13'),
('21', 'operating_hours_restaurant', '12:00 - 22:00', '2025-08-17 19:51:13'),
('22', 'operating_hours_pool', '9:00 - 21:00', '2025-08-17 19:51:13'),
('23', 'operating_hours_sauna', '16:00 - 22:00', '2025-08-17 19:51:13'),
('28', 'address', '', '2025-08-19 07:21:53'),
('29', 'opening_hours', '', '2025-08-19 07:21:53');

COMMIT;
